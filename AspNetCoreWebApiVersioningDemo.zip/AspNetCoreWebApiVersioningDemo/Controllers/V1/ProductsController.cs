﻿using Microsoft.AspNetCore.Mvc;
using AspNetCoreWebApiVersioningDemo.Services.V1;

namespace AspNetCoreWebApiVersioningDemo.Controllers.V1
{
    //[Route("api/{version:apiVersion}/[controller]")]
    //[ApiVersion("1.0")]
    
    [ApiVersion("1.0", Deprecated = true)]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpGet]
        public IActionResult GetProducts()
        {
            return Ok(_productService.GetProducts());
        }
    }
}
