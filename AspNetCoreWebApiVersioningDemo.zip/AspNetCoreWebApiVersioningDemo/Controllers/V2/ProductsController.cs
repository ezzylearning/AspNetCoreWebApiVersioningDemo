﻿using Microsoft.AspNetCore.Mvc;
using AspNetCoreWebApiVersioningDemo.Services.V2;

namespace AspNetCoreWebApiVersioningDemo.Controllers.V2
{

    //[Route("api/{version:apiVersion}/[controller]")]

    [ApiVersion("2.0")]
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;

        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }

        [HttpGet]
        public IActionResult GetProducts()
        {
            return Ok(_productService.GetProducts());
        }
    }
}
