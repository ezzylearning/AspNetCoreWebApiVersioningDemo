﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AspNetCoreWebApiVersioningDemo.Models.V1;

namespace AspNetCoreWebApiVersioningDemo.Services.V1
{
    public interface IProductService
    {
        public List<Product> GetProducts();
    }
}
