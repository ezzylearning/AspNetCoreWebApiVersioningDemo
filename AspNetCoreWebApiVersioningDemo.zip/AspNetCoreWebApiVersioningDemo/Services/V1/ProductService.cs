﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using AspNetCoreWebApiVersioningDemo.Models.V1;

namespace AspNetCoreWebApiVersioningDemo.Services.V1
{
    public class ProductService : IProductService
    {
        public List<Product> GetProducts()
        {
            return new List<Product>()
            {
                new Product()
                {
                    Id = 1,
                    Name = "Wireless Mouse",
                    Price = 29.99m 
                },
                new Product()
                {
                    Id = 2,
                    Name = "HP Headphone",
                    Price = 79.99m 
                },
                new Product()
                {
                    Id = 3,
                    Name = "Sony Keyboard",
                    Price = 119.99m 
                }
            };
        }
    }
}
