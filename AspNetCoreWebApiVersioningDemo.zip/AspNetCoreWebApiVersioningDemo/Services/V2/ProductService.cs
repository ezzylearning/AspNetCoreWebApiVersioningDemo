﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using AspNetCoreWebApiVersioningDemo.Models.V2;

namespace AspNetCoreWebApiVersioningDemo.Services.V2
{
    public class ProductService : IProductService
    {
        public List<Product> GetProducts()
        {
            return new List<Product>()
            {
                new Product()
                {
                    Id = 1,
                    Name = "Wireless Mouse",
                    Price = 29.99m, 
                    Orders = new List<Order>()
                    {
                        new Order()
                        {
                            Id = 1,
                            OrderNo = "12345",
                            OrderDate = DateTime.Today.AddDays(-2),
                            Status = "Pending" 
                        },
                        new Order()
                        {
                            Id = 2,
                            OrderNo = "67890",
                            OrderDate = DateTime.Today.AddDays(-5),
                            Status = "Completed" 
                        }
                    }
                },
                new Product()
                {
                    Id = 2,
                    Name = "HP Headphone",
                    Price = 79.99m, 
                    Orders = new List<Order>()
                    {
                        new Order()
                        {
                            Id = 3,
                            OrderNo = "13579",
                            OrderDate = DateTime.Today.AddDays(-7),
                            Status = "Completed" 
                        }
                    }
                },
                new Product()
                {
                    Id = 3,
                    Name = "Sony Keyboard",
                    Price = 119.99m 
                }
            };
        }
    }
}
